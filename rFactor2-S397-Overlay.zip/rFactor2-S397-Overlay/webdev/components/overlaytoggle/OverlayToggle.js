angular.module('controlpanel.overlayToggle', []).component('overlayToggle', {
    bindings: {
        overlay: '<',
        toggleOverlay: '&'
    },
    templateUrl: '/webdev/components/overlaytoggle/overlaytoggle.html'
});
