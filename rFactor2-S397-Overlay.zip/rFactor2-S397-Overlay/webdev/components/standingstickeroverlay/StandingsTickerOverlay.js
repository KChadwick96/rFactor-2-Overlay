angular.module('overlay.standingsTicker', []).component('standingsTickerOverlay', {
    bindings: {
        overlayInfo: '<',
        sessionInfo: '<',
        drivers: '<',
        carClass: '<'
    },
    templateUrl: '/webdev/components/standingstickeroverlay/standingsticker.overlay.html',
    controller: function (broadcastService, $animate, $timeout, $scope) {
        var ctrl = this;
        var container;
        var listElement;
        var listCloneElement;
        var transition = 'transform 2000ms linear'; // Ticker scrolling transition
        ctrl.showClone = false;

        this.$onInit = function () {
            container = document.querySelector('standings-ticker-overlay');
            listElement = document.querySelector('.standings-ticker');
            listCloneElement = document.querySelector('.standings-ticker-clone');
            listElement.addEventListener('transitionend', animateTicker);

            $scope.$watch('$ctrl.overlayInfo', function (newVal, oldVal) {
                if (newVal && oldVal && newVal.visible && !oldVal.visible) {
                    listElement.style.transform = 'skewX(-22deg) translateX(6rem)';
                    listCloneElement.style.transform = 'skewX(-22deg) translateX(100%)';

                    $timeout(function () {
                        animateTicker();
                    }, 2000);
                }
            }, true);

            $scope.$watch('$ctrl.carClass', function (newVal, oldVal) {
                if (newVal == oldVal) {
                    return;
                }

                listElement.style.visibility = 'hidden';
                ctrl.showClone = false;

                // Return to original position
                listElement.style.transition = 'transform 0ms linear';
                listCloneElement.style.transition = 'transform 0ms linear';
                listElement.style.transform = 'skewX(-22deg) translateX(6rem)';
                listCloneElement.style.transform = 'skewX(-22deg) translateX(100%)';

                $timeout(function () {
                    listElement.style.visibility = 'visible';
                }, 1000);

                $timeout(function () {
                    animateTicker();
                }, 2000);
            }, true);
        }

        this.$onChanges = function (changes) {
            if (changes.drivers) {
                var newVal = changes.drivers.currentValue;
                var oldVal = changes.drivers.previousValue;

                if (newVal.length !== oldVal.length) {
                    return;
                }

                animatePositionChange(newVal, oldVal);
            }
        }

        $timeout(() => {
            animateTicker();
        }, 2000);

        this.displayGap = function (entry) {
            return broadcastService.displayGap(entry, this.drivers, this.sessionInfo, this.carClass);
        }

        this.displayTime = function (entry) {
            return broadcastService.displayTime(entry, this.sessionInfo);
        }

        function animatePositionChange (newVal, oldVal) {
            _.forEach(newVal, (newEntry) => {
                var oldEntry = _.find(oldVal, (oldEntry) => {
                    return newEntry.slotID === oldEntry.slotID;
                });

                if (oldEntry && oldEntry.position !== newEntry.position) {
                    var elem = document.getElementsByClassName('ticker-slot-id-' + newEntry.slotID)[0];
                    var moveAmount;

                    if (!elem) {
                        return;
                    }

                    if (newEntry.position < oldEntry.position) {
                        moveAmount = (oldEntry.position - newEntry.position) * 100;
                    } else {
                        moveAmount = ((newEntry.position - oldEntry.position) * 100) * -1;
                    }

                    elem.style.transform = 'translateX(' + moveAmount + '%)';

                    $animate.addClass(elem, 'animate-move').then(() => {
                        elem.classList.remove('animate-move');
                    });

                    $timeout(() => {
                        elem.style.transform = 'translateX(0)';
                    }, 0);
                }
            });
        }

        function animateTicker () {
            if (listElement.clientWidth > container.clientWidth) {
                // Ticker is wider than the parent container, so we need to scroll it
                ctrl.showClone = true;
                scrollTicker();
            } else {
                if (ctrl.showClone) {
                    // Return to original position
                    listElement.style.transform = 'skewX(-22deg) translateX(' + document.querySelector('.ticker-slot-position').getBoundingClientRect().width + 'px)';
                    listCloneElement.style.transform = 'skewX(-22deg) translateX(' + document.querySelector('.standings-ticker').clientWidth + 'px)';
                }

                // Hide the clone
                ctrl.showClone = false;
            }
        }

        function scrollTicker () {
            var scrollTransition = transition;
            var translateX = parseInt(getComputedStyle(listElement).transform.split(', ')[4]);
            var moveAmount = -100;

            if (Math.abs(translateX) > listElement.clientWidth + 50) {
                // Ticker scrolled off the left edge, reset position before animating the transition
                translateX = -1 * (Math.abs(translateX) - listElement.clientWidth);
                setTranslateXTransition('initial', translateX, translateX + listElement.clientWidth);
                translateX = parseInt(getComputedStyle(listElement).transform.split(', ')[4]);

                $timeout(function () {
                    scrollTicker();
                });
            } else {
                translateX += moveAmount;
            }

            setTranslateXTransition(scrollTransition, translateX, translateX + listElement.clientWidth);
        }

        function setTranslateXTransition (transition, listTranslateX, cloneTranslateX, unit = 'px') {
            listElement.style.transition = transition;
            listElement.style.transform = 'skewX(-22deg) translateX(' + listTranslateX + unit + ')';
            listCloneElement.style.transition = transition;
            listCloneElement.style.transform = 'skewX(-22deg) translateX(' + cloneTranslateX + unit + ')';
        }
    }
});
