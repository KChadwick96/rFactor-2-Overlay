angular.module('overlay.logo', []).component('logoOverlay', {
    bindings: {
        sessionInfo: '<',
        overlayInfo: '<'
    },
    templateUrl: '/webdev/components/logooverlay/logo.overlay.html',
    controller: function overlaySessionInfoController(broadcastService) {
        this.displaySessionName = function () {
            return broadcastService.displaySessionName(this.sessionInfo);
        }

        this.displaySessionDuration = function () {
            return broadcastService.displaySessionDuration(this.sessionInfo);
        }
    }
});
