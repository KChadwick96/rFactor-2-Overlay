angular.module('overlay.finalResults', []).component('finalResultsOverlay', {
    bindings: {
        overlayInfo: '<',
        sessionResults: '<'
    },
    templateUrl: '/webdev/components/finalresultsoverlay/finalresults.overlay.html',
    controller: function (broadcastService) {
        var ctrl = this;
        ctrl.sessionInfo = null;

        broadcastService.getSessionInfo().then(function (response) {
            ctrl.sessionInfo = response.data;
        });

        this.displaySessionName = function () {
            if (ctrl.overlayInfo && ctrl.overlayInfo.session) {
                return broadcastService.displaySessionName(ctrl.overlayInfo);
            }
        }

        this.displayGap = function (entry) {
            return broadcastService.displayFinalGap(entry, ctrl.sessionResults, ctrl.overlayInfo);
        }

        this.sessionBestLapTime = () => {
            return broadcastService.sessionBestLapTime(ctrl.sessionResults);
        }
    }
}).filter('sessionResultsPage', function () {
    return (items, page, perPage) => {
        if (page > 1) {
            items.splice(0, (page - 1) * perPage);
        }

        return items;
    }
});
