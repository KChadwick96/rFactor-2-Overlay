angular.module('overlay.sessionInfoLarge', []).component('sessionInfoLargeOverlay', {
    bindings: {
        sessionInfo: '<',
        overlayInfo: '<'
    },
    templateUrl: '/webdev/components/sessioninfolargeoverlay/sessioninfolarge.overlay.html',
    controller: function overlaySessionInfoController(broadcastService) {
        var ctrl = this;

        this.displaySessionName = function () {
            return broadcastService.displaySessionName(this.sessionInfo);
        }

        this.displaySessionDuration = function (duration) {
            return broadcastService.displaySessionDuration(duration);
        }

        ctrl.secToString= function (value) {
            return broadcastService.secToString(value);
        }

        ctrl.displayTemperature = function (value) {
            var temp = value.toFixed(1);

            return temp + " °C";
        }
    }
});
