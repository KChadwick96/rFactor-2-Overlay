angular.module('controlpanel.standingsTowerSettings', []).component('standingsTowerSettings', {
    bindings: {
        drivers: '<',
        driversPerPage: '<',
        page: '<',
        carClass: '<',
        showName: '<',
        updateSettings: '&',
    },
    templateUrl: '/webdev/components/standingstowersettings/standingstowersettings.html',
    controller: function () {
        this.carClasses = [
            'LMP2',
            'LMP3',
            'GTE',
            'GT3'
        ];

        this.getStandingsTowerPageCount = function () {
            var drivers = this.drivers;

            if (this.carClass && this.carClass !== 'All') {
                drivers = _.filter(drivers, { carClass: this.carClass });
            }

            if (!drivers || drivers.length === 0) {
                return;
            }

            var pageCount = 0;
            var driverCount = 0;

            while (driverCount <= drivers.length - 1) {
                if (pageCount === 0) {
                    driverCount += this.driversPerPage;
                } else {
                    driverCount += this.driversPerPage - 1;
                }

                pageCount++;
            }

            return pageCount;
        }

        this.update = function () {
            if (this.page > this.getStandingsTowerPageCount()) {
                this.page = this.getStandingsTowerPageCount();
            }

            this.updateSettings({
                driversPerPage: this.driversPerPage,
                page: this.page,
                carClass: this.carClass,
                showName: this.showName
            });
        }
    }
});
