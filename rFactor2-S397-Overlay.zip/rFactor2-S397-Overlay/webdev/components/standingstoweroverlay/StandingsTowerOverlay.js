angular.module('overlay.standingsTower', []).component('standingsTowerOverlay', {
    bindings: {
        overlayInfo: '<',
        sessionInfo: '<',
        drivers: '<',
        carClass: '<'
    },
    templateUrl: '/webdev/components/standingstoweroverlay/standingstower.overlay.html',
    controller: function (broadcastService, $animate, $timeout) {
        var ctrl = this;

        this.$onChanges = function (changes) {
            if (changes.drivers) {
                var newVal = changes.drivers.currentValue;
                var oldVal = changes.drivers.previousValue;

                if (newVal.length !== oldVal.length) {
                    return;
                }

                animatePositionChange(newVal, oldVal);
            }
        }

        this.isRaceSession = function () {
            return broadcastService.isRaceSession(this.sessionInfo);
        }

        this.displaySessionName = function () {
            return broadcastService.displaySessionName(this.sessionInfo);
        }

        this.displaySessionDuration = function () {
            return broadcastService.displaySessionDuration(this.sessionInfo);
        }

        this.displayGap = function (entry) {
            return broadcastService.displayGap(entry, this.drivers, this.sessionInfo, this.carClass);
        }

        this.sessionBestLapTime = () => {
            return broadcastService.sessionBestLapTime(this.drivers);
        }

        ctrl.shortenName = function (name) {
            var shortenedName = '';
            var parts = name.trim().split(' ');

            if (parts.length > 1) {
                //shortenedName = parts[0][0] + '. ' + parts[parts.length - 1].substr(0, 3);
				shortenedName = parts[0][0] + '. ' + parts[parts.length - 1];//.substr(0, 3);
            }

            /*if (shortenedName.length === 0 || shortenedName.length > 6) {
                shortenedName = name.substr(0, 6);
            }*/

            return shortenedName;
        }

        function animatePositionChange (newVal, oldVal) {
            _.forEach(newVal, (newEntry) => {
                var oldEntry = _.find(oldVal, (oldEntry) => {
                    return newEntry.slotID === oldEntry.slotID;
                });

                if (oldEntry && oldEntry.position !== newEntry.position) {
                    var elem = document.getElementsByClassName('slot-' + newEntry.slotID)[0];
                    var moveAmount;

                    if (!elem
                        || newEntry.position > ctrl.overlayInfo.driversPerPage * ctrl.overlayInfo.page
                        || newEntry.position <= ctrl.overlayInfo.driversPerPage * ctrl.overlayInfo.page - ctrl.overlayInfo.driversPerPage) {
                        // Do not animate if new position is on another page
                        return;
                    }

                    if (newEntry.position < oldEntry.position) {
                        moveAmount = (oldEntry.position - newEntry.position) * 100;
                    } else {
                        moveAmount = ((newEntry.position - oldEntry.position) * 100) * -1;
                    }

                    elem.style.transform = 'translateY(' + moveAmount + '%)';

                    $animate.addClass(elem, 'animate-move').then(() => {
                        elem.classList.remove('animate-move');
                    });

                    $timeout(() => {
                        elem.style.transform = 'translateX(0)';
                    }, 0);
                }
            });
        }
    }
}).filter('page', function () {
    return (items, page, perPage) => {
        if (page > 1) {
            items.splice(1, (page - 1) * (perPage - 1));
        }

        return items;
    }
});
