var overlaysApp = angular.module('overlaysApp', [
    'ngAnimate',
    'BroadcastService',
    'overlay.driverInfo',
    'overlay.finalResults',
    'overlay.sessionInfo',
    'overlay.logo',
    'overlay.sessionInfoLarge',
    'overlay.standingsTicker',
    'overlay.standingsTower',
    'overlay.standingsInfo',
    'overlay.trackMap'
]);

overlaysApp.controller('OverlaysController', function (broadcastService, $scope, $http, $interval) {
    //TODO: Reset after finish
    var restUrl = '/rest/watch/';
    var webdataUrl = '/webdata/';
    var ctrl = this;
    ctrl.sessionInfo = null;
    ctrl.drivers = [];
    ctrl.selectedDriver = null;
    ctrl.overlays = {};
    ctrl.sessionResults = [];
    ctrl.trackMap = null;

    getOverlayData();
    getSessionData();
    getStandingsData();

    broadcastService.getTrackMap().then(function (response) {
        ctrl.trackMap = response.data;
    });

    $interval(function () {
        getSessionData();
        getStandingsData();
    }, 1000);

    $interval(function () {
        getOverlayData();
    }, 500);

    function getResults () {
        $http.get(webdataUrl + 'results').then(function (response) {
            var resultsSession = _.find(response.data, (entry) => {
                return entry.session === ctrl.overlays.finalResults.session;
            });

            if (resultsSession) {
                var sessionResults = [];
                var resultsSorted = _.sortBy(resultsSession.results, 'position');
                var firstLMP2Found = 0;
                var firstLMP3Found = 0;
                var firstGTEFound = 0;
                var firstGT3Found = 0;

                resultsSorted.forEach(function (element) {
                    if (element.carClass === 'LMP2' && firstLMP2Found === 0) {
                        element.isClassLeader = 1;
                        firstLMP2Found = 1;
                    } else if (element.carClass === 'LMP3' && firstLMP3Found === 0) {
                        element.isClassLeader = 1;
                        firstLMP3Found = 1;
                    } else if (element.carClass === 'GTE' && firstGTEFound === 0) {
                        element.isClassLeader = 1;
                        firstGTEFound = 1;
                    } else if (element.carClass === 'GT3' && firstGT3Found === 0) {
                        element.isClassLeader = 1;
                        firstGT3Found = 1;
                    } else {
                        element.isClassLeader = 0;
                    }

                    sessionResults.push(element);
                });

                ctrl.sessionResults = sessionResults;
            }
        });
    }

    function getOverlayData () {
        //TODO: Reset after finish
        $http.get('/webdata/overlays').catch(function (reason) {
            ctrl.overlays = broadcastService.getOverlayDefaultConfig();

            if (!ctrl.overlays.carClass) {
                ctrl.overlays.carClass = 'All';
            }

            return reason;
        }).then(function (response) {
            if (response.status === 200) {
                ctrl.overlays = response.data;
            }
        }).finally(function () {
            getResults();
        });
    }

    function getSessionData () {
        $http.get(restUrl + 'sessionInfo').then(function (response) {
            ctrl.sessionInfo = response.data;
        });
    }

    function getStandingsData () {
        $http.get(restUrl + 'standings').then(function (response) {
            var drivers = [];
            var firstLMP2Found = 0;
            var firstLMP3Found = 0;
            var firstGTEFound = 0;
            var firstGT3Found = 0;
            var driversSorted = _.sortBy(response.data, 'position');
            var classLeader = {};

            if (ctrl.overlays.carClass && ctrl.overlays.carClass !== 'All') {
                driversSorted = _.filter(driversSorted, { carClass: ctrl.overlays.carClass });
            }

            _.forEach(driversSorted, (element, $index) => {
                element.classPosition = _.findIndex(_.filter(driversSorted, { carClass: element.carClass }), { slotID: element.slotID }) + 1;

                if (element.carClass === 'LMP2' && firstLMP2Found === 0) {
                    element.isClassLeader = 1;
                    drivers.push(element);
                    firstLMP2Found = 1;
                    classLeader.LMP2 = element;
                } else if (element.carClass === 'LMP3' && firstLMP3Found === 0) {
                    element.isClassLeader = 1;
                    drivers.push(element);
                    firstLMP3Found = 1;
                    classLeader.LMP3 = element;
                } else if (element.carClass === 'GTE' && firstGTEFound === 0) {
                    element.isClassLeader = 1;
                    drivers.push(element);
                    firstGTEFound = 1;
                    classLeader.GTE = element;
                } else if (element.carClass === 'GT3' && firstGT3Found === 0) {
                    element.isClassLeader = 1;
                    drivers.push(element);
                    firstGT3Found = 1;
                    classLeader.GT3 = element;
                } else {
                    element.isClassLeader = 0;
                    drivers.push(element);
                }
            });

            ctrl.drivers = drivers;

            $http.get(restUrl + 'focus').then(function (focus) {
                if (focus.data !== -1) {
                    ctrl.selectedDriver = _.find(response.data, function (entry) {
                        return entry.slotID === focus.data;
                    });
                }
            });
        });
    }
});
