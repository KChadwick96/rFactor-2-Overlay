angular.module('BroadcastService', []).service('broadcastService', function ($http) {
    //TODO: Remove nach Finalisierung
    var restUrl = '/rest/watch/';
    var webdataUrl = '/webdata/';
    var service = {
        getOverlayDefaultConfig: getOverlayDefaultConfig,
        getOverlays: getOverlays,
        saveOverlays: saveOverlays,
        getSessionInfo: getSessionInfo,
        getStandings: getStandings,
        getSessionResults: getSessionResults,
        createSessionResults: createSessionResults,
        saveSessionResults: saveSessionResults,
        getTrackMap: getTrackMap,
        isRaceSession: isRaceSession,
        displaySessionName: displaySessionName,
        displaySessionDuration: displaySessionDuration,
        sessionBestLapTime: sessionBestLapTime,
        displayTime: displayTime,
        displayGap: displayGap,
        displayFinalGap: displayFinalGap,
        secToString: secToString
    }

    return service;

    function getOverlayDefaultConfig () {
        return {
            carClass: 'All',
            logo: {
                name: 'Logo',
                key: 'logo',
                visible: false,
                disableOverlays: ['finalResults']
            },
            sessionInfo: {
                name: 'Session info',
                key: 'sessionInfo',
                visible: false,
                disableOverlays: ['finalResults']
            },
            sessionInfoLarge: {
                name: 'Session info large',
                key: 'sessionInfoLarge',
                visible: false,
                disableOverlays: ['finalResults']
            },
            driverInfo: {
                name: 'Driver info',
                key: 'driverInfo',
                visible: false,
                disableOverlays: ['finalResults']
            },
            standingsTower: {
                name: 'Standings tower',
                key: 'standingsTower',
                visible: false,
                driversPerPage: 40,
                page: 1,
                showName: 'Driver',
                disableOverlays: ['standingsTicker', 'finalResults']
            },
            standingsTicker: {
                name: 'Standings ticker',
                key: 'standingsTicker',
                visible: false,
                disableOverlays: ['standingsTower', 'finalResults']
            },
            standingsInfo: {
                name: 'Standings Info',
                key: 'standingsInfo',
                visible: false,
                driversPerPage: 20,
                page: 1,
                disableOverlays: ['standingsTicker', 'finalResults']
            },
            finalResults: {
                name: 'Results',
                key: 'finalResults',
                visible: false,
                driversPerPage: 15,
                page: 1,
                session: null,
                disableOverlays: ['sessionInfo', 'driverInfo', 'standingsTower', 'standingsTicker', 'trackMap']
            },
            trackMap: {
                name: 'Track map',
                key: 'trackMap',
                visible: false,
                highlightSelected: true,
                disableOverlays: ['finalResults']
            },
            code80: {
                name: 'Code 80',
                key: 'code80',
                visible: false
            },
        };
    }

    function getOverlays () {
        //TODO: Remove after finish
        return $http.get('/webdata/overlays');
    }

    function saveOverlays (overlays) {
        return $http.post(webdataUrl + 'overlays', overlays);
    }

    function getSessionInfo () {
        return $http.get(restUrl + 'sessionInfo').then(function (response) {
            return response;
        });
    }

    function getStandings () {
        return $http.get(restUrl + 'standings').then(function (response) {
            return response;
        });
    }

    function getSessionResults () {
        return $http.get(webdataUrl + 'results').catch(function (reason) {
            return reason;
        }).then(function (response) {
            return response;
        });
    }

    function createSessionResults (session, results) {
        var sessionResults = [];

        sessionResults.push({
            session: session,
            results: results
        })

        return sessionResults;
    }

    function saveSessionResults (session, standings, sessionResults) {
        var sessionEntryIndex = _.findIndex(sessionResults, function (entry) {
            return entry.session === session;
        });

        if (sessionEntryIndex !== -1) {
            sessionResults[sessionEntryIndex].results = standings;
        } else {
            sessionResults.push({
                session: session,
                results: standings
            });
        }

        $http.post(webdataUrl + 'results', sessionResults);
    }

    function getTrackMap () {
        return $http.get(restUrl + 'trackmap');
    }

    function isRaceSession (sessionInfo) {
        return sessionInfo && sessionInfo.session && sessionInfo.session.indexOf('RACE') !== -1;
    }

    function displaySessionName (sessionInfo) {
        if (!sessionInfo) {
            return '---';
        }

        return sessionInfo.session.replace(/\d/g, '').toLowerCase();
    }

    function displaySessionDuration (sessionInfo) {
        var durationText = '---';

        if (!sessionInfo) {
            return durationText;
        }

        if (!isRaceSession(sessionInfo)) {
            durationText = displaySessionTimeLeft(sessionInfo);
        } else if (sessionInfo.maximumLaps !== 2147483647) {
            // Lap-based race
            durationText = sessionInfo.maximumLaps + ' laps';
        } else if (sessionInfo.endEventTime > 0) {
            // Timed race
            durationText = displaySessionTimeLeft(sessionInfo);
        }

        return durationText;
    }

    function displaySessionTimeLeft (sessionInfo) {
        return secToString(sessionInfo.endEventTime - sessionInfo.currentEventTime);
    }

    // Overall fastest lap time in the session
    function sessionBestLapTime (drivers) {
        return _.minBy(drivers, (entry) => {
            if (entry.bestLapTime !== -1) {
                return entry.bestLapTime;
            }
        }).bestLapTime;
    }

    function displayTime (entry, sessionInfo) {
        return isRaceSession(sessionInfo) ? secToString(entry.lastLapTime, 3, true) : secToString(entry.bestLapTime,3, true);
    }

    function displayGap (entry, drivers, sessionInfo, carClass) {
        var gapText = '---';

        if (isRaceSession(sessionInfo)) {
            if (entry.position === 1 || ((!carClass || carClass !== 'All') && entry.classPosition === 1)) {
                // Overall or class leader
                gapText = 'lap ' + (entry.lapsCompleted + 1);
            } else {
                // Not the leader nor class leader
                if (!carClass || carClass === 'All') {
                    // Showing overall standings
                    if (entry.lapsBehindNext === 0) {
                        // In race show gap to next driver, not leader
                        gapText = secToString(entry.timeBehindNext, 3);
                    } else {
                        gapText = entry.lapsBehindNext + ' ';
                        gapText += entry.lapsBehindNext > 1 ? 'laps' : 'lap';
                    }
                } else {
                    // Showing class standings
                    if (entry.lapsBehindNext === 0) {
                        // In race show gap to next driver, not leader
                        gapText = secToString(entry.timeBehindNext, 3);
                    } else {
                        gapText = entry.lapsBehindNext + ' ';
                        gapText += entry.lapsBehindNext > 1 ? 'laps' : 'lap';
                    }
                }
            }
        } else {
            if (entry.position === 1 || ((!carClass || carClass !== 'All') && entry.classPosition === 1)) {
                gapText = secToString(entry.bestLapTime, 3)
            } else if (entry.position > 1 || (carClass !== 'All' && entry.classPosition > 1)) {
                if (carClass === 'All') {
                    var firstPlace = _.find(drivers, { position: 1});
                } else {
                    var firstPlace = _.find(drivers, { classPosition: 1, carClass: carClass });
                }

                if (firstPlace) {
                    gapText = secToString(entry.bestLapTime - firstPlace.bestLapTime, 3);
                }
            }
        }

        return gapText;
    }

    function displayFinalGap (entry, drivers, sessionInfo) {
        var gapText = '---';

        if (isRaceSession(sessionInfo)) {
            if (entry.position === 1) {
                gapText = 'winner';
            } else {
                if (entry.lapsBehindLeader === 0) {
                    var firstPlace = _.find(drivers, { position: 1 });

                    gapText = secToString(entry.lapStartET - firstPlace.lapStartET, 3);
                } else {
                    gapText = entry.lapsBehindLeader + ' ';
                    gapText += entry.lapsBehindLeader > 1 ? 'laps' : 'lap';
                }
            }
        } else {
            gapText = secToString(entry.bestLapTime, 3)
        }

        return gapText;
    }

    function secToString (value, n = 0) {
        if (value <= 0) {
            return '---';
        }

        var pad = (n, width, z = '0') => {
            z = z || '0';
            n = n + '';
            return n.length >= width ? n : new Array(width - n.length + 1).join(z) + n;
        }

        var hours = Math.floor(value / 3600);
        var minutes = Math.floor((value - hours * 3600) / 60);
        var seconds = value - hours * 3600 - minutes * 60;
        var time = '';
        if (hours != 0) {
            time += hours + ":";
            time += pad(minutes, 2) + ":";
        } else {
            time += minutes != 0 ? minutes + ":" : "";
        }
        time += value > 60 ? pad(seconds.toString().split(".")[0], 2) : seconds.toString().split(".")[0];
        if (n > 0) {
            n = n > 3 ? 3 : n;
            var ms = "";
            var roundedSeconds = _.round(seconds, 3).toString();
            if (roundedSeconds.indexOf('.') != -1) {
                ms = roundedSeconds.split(".")[1].slice(0, n);
                if (ms.length < n) {
                    var addCount = n - ms.length;
                    for (var i = 0; i < addCount; i++) {
                        ms += "0";
                    }
                }
            } else {
                ms = pad(0, 3);
            }
            time += "." + ms;
        }
        time = time == '0' ? "---" : time;
        time = time === '1:0' ? '1:00' : time;
        return time;
    }
});
