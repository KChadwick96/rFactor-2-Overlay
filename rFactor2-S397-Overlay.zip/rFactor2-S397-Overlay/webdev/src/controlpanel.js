var controlPanelApp = angular.module('controlPanelApp', [
    'BroadcastService',
    'controlpanel.cameraControl',
    'controlpanel.standingsTowerSettings',
    'controlpanel.overlayToggle',
    'controlpanel.finalResultsSettings',
]);

controlPanelApp.controller('ControlPanelController', function (broadcastService, $scope, $http, $interval) {
    var restUrl = '/rest/watch/';
    var ctrl = this;
    ctrl.sessionInfo = [];
    ctrl.drivers = [];
    ctrl.selectedDriver = {};
    ctrl.overlays = null;
    ctrl.sessionResults = [];
    ctrl.broadcastService = broadcastService;

    updateData();

    $interval(function () {
        updateData();
    }, 3000);

    function updateData () {
        broadcastService.getSessionInfo().then(function (response) {
            ctrl.sessionInfo = response.data;

            if (response.data.session === 'INVALID') {
                return;
            }

            broadcastService.getStandings().then(function (response) {
                ctrl.drivers = response.data;

                $http.get(restUrl + 'focus').then(function (response) {
                    if (response.data !== -1) {
                        ctrl.selectedDriver = ctrl.drivers.find(function (entry) {
                            return entry.slotID === response.data;
                        });
                    }
                });

                broadcastService.getSessionResults().then(function (response) {
                    if (response.status === 200) {
                        ctrl.sessionResults = response.data;
                    } else {
                        ctrl.sessionResults = broadcastService.createSessionResults(ctrl.sessionInfo.session, ctrl.drivers);
                    }

                    broadcastService.saveSessionResults(ctrl.sessionInfo.session, ctrl.drivers, ctrl.sessionResults);

                    broadcastService.getOverlays().catch(function (reason) {
                        ctrl.overlays = broadcastService.getOverlayDefaultConfig();

                        return reason;
                    }).then(function (response) {
                        if (response.status === 200) {
                            ctrl.overlays = response.data;
                        }
                    }).finally(function () {
                        // Set the first session as default for the results overlay
                        if (ctrl.overlays.finalResults.session === null) {
                            ctrl.overlays.finalResults.session = ctrl.sessionResults[0].session;
                            broadcastService.saveOverlays(ctrl.overlays);
                        }
                    });
                });
            });
        });
    }

    ctrl.onUpdateStandingsTowerSettings = function (driversPerPage, page, carClass, showName) {
        if (!carClass) {
            carClass = 'All';
        }

        if (ctrl.overlays) {
            ctrl.overlays.carClass = carClass;
            ctrl.overlays.standingsTower.driversPerPage = driversPerPage;
            ctrl.overlays.standingsTower.page = page;
            ctrl.overlays.standingsTower.showName = showName;
            broadcastService.saveOverlays(ctrl.overlays);
        }
    }

    ctrl.onUpdateResultsSettings = function (driversPerPage, page, session) {
        ctrl.overlays.finalResults.driversPerPage = driversPerPage;
        ctrl.overlays.finalResults.page = page;
        ctrl.overlays.finalResults.session = session;
        broadcastService.saveOverlays(ctrl.overlays);
    }

    ctrl.onToggleOverlay = function(overlay) {
        ctrl.overlays[overlay].visible = !ctrl.overlays[overlay].visible;

        if (ctrl.overlays[overlay].disableOverlays) {
            _.forEach(ctrl.overlays[overlay].disableOverlays, function (disableOverlay) {
                ctrl.overlays[disableOverlay].visible = false;
            });
        }

        broadcastService.saveOverlays(ctrl.overlays);
    }

    ctrl.onSelectDriver = function(driver) {
        if (driver.slotID === ctrl.selectedDriver.slotID) {
            return;
        }

        $http.put(restUrl + 'focus/' + driver.slotID, { slotID: driver.slotID }).then(function (response) {
            if (response.status >= 200 && response.status <= 299) {
                ctrl.selectedDriver = driver;
            }
        });
    }

    ctrl.onSelectCamera = function(driver, type, trackSideGroup, shouldAdvance) {
        $http.put(restUrl + 'focus/' + type + '/' + trackSideGroup + '/' + shouldAdvance, {}).then(function () {
            ctrl.onSelectDriver(driver);
        });
    }
});
