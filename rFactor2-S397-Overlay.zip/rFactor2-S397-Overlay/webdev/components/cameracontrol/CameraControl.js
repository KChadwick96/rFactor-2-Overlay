angular.module('controlpanel.cameraControl', []).component('cameraControl', {
    bindings: {
        drivers: '<',
        selectedDriver: '<',
        selectDriver: '&',
        selectCamera: '&'
    },
    templateUrl: '/webdev/components/cameracontrol/cameracontrol.html',
});
