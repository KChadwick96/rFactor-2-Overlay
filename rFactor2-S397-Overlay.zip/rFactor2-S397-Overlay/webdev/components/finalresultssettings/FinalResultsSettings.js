angular.module('controlpanel.finalResultsSettings', []).component('finalResultsSettings', {
    bindings: {
        drivers: '<',
        driversPerPage: '<',
        page: '<',
        updateSettings: '&',
        sessionResults: '<',
        session: '<'
    },
    templateUrl: '/webdev/components/finalresultssettings/finalresultssettings.html',
    controller: function () {
        this.getPageCount = function () {
            return Math.ceil(this.drivers.length / this.driversPerPage);
        }

        this.update = function () {
            if (this.page > this.getPageCount()) {
                this.page = this.getPageCount();
            }

            this.updateSettings({ driversPerPage: this.driversPerPage, page: this.page, session: this.session });
        }
    }
});
