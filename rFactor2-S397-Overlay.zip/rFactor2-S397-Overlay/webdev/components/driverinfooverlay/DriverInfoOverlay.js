angular.module('overlay.driverInfo', []).component('driverInfoOverlay', {
    bindings: {
        overlayInfo: '<',
        selectedDriver: '<'
    },
    templateUrl: '/webdev/components/driverinfooverlay/driverinfo.overlay.html',
    controller: function (broadcastService) {
        this.formatLapTime = function (lapTime) {
            return broadcastService.secToString(lapTime, 3);
        }
    }
});
